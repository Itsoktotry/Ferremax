from django.db import models
from django.utils import timezone

class Formulario(models.Model):
    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    direccion = models.CharField(max_length=200)
    comuna = models.CharField(max_length=100)
    problema = models.TextField()

    def __str__(self):
        return self.nombre 
    


class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    imagen = models.ImageField(upload_to='productos')
    categoria = models.CharField(max_length=100, default='Sin categoría')
    fecha = models.DateField(default=timezone.now)
    mecanico = models.CharField(max_length=100, default='Sin categoría')
    diagnostico = models.CharField(max_length=100, default='Sin categoría')
    repuestos = models.CharField(max_length=100, default='Sin categoría')

    
    def __str__(self):
        return self.nombre
    







