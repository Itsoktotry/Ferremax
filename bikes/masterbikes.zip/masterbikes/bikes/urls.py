from django.urls import path

from .views import *

urlpatterns = [
    path('',principal,name='principal' ),
    path('formulario',formulario,name='formulario' ),
    path('registro',registro,name='registro' ),
    path('catalogo/', catalogo, name='catalogo'),
    path('ordenarn', ordenarn, name='ordenarn'),
    path('ordenarc', ordenarc, name='ordenarc'),
    path('formulariom',formulariom,name='formulariom' ),
    path('solicitudes',solicitudes,name='solicitudes' ),
    path('solicitudesm',solicitudesm,name='solicitudesm' ),
    path('producto/<str:producto_nombre>/', detalle_producto_view, name='detalle_producto'),
    path('buscar', buscar, name='buscar'),
]
