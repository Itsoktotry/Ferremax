from django.shortcuts import render,redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Formulario,Producto
from .forms import CustomUserCreationForm
from django.contrib.auth import authenticate,login
from django.contrib import messages

from .models import Formulario
from .forms import ProductoForm


def principal(request):
    productos = Producto.objects.all()
    if request.user.is_authenticated:

        return(render(request,'index.html', {'productos': productos}))
    else:
        return render(request,'index.html', {'productos': productos})
    




def formulario(request):
    if request.method == 'POST':
        nombre = request.user.username
        telefono = request.POST['telefono']
        direccion = request.POST['direccion']
        comuna = request.POST['comuna']
        problema = request.POST['problema']

        formulario = Formulario(
            nombre=nombre,
            telefono=telefono,
            direccion=direccion,
            comuna=comuna,
            problema=problema
        )
        formulario.save()


    return render(request, 'formulario.html')  



def registro(request):  
    data = { 

        'form' :  CustomUserCreationForm()
    }

    if request.method == 'POST':
        formulario = CustomUserCreationForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            user = authenticate(username=formulario.cleaned_data["username"],password=formulario.cleaned_data["password1"])
            login(request,user)
            messages.success(request,"Te has registrado correctamente")
            return redirect(to="principal")
        data['form'] = formulario

    return render(request,'registration/registro.html',data)




def catalogo(request):
    productos = Producto.objects.all()
    return render(request, 'catalogo.html', {'productos': productos})



def ordenarn(request):
    productos = Producto.objects.order_by('mecanico')
    return render(request, 'catalogo.html', {'productos': productos})

def ordenarc(request):
    productos = Producto.objects.order_by('categoria')
    return render(request, 'catalogo.html', {'productos': productos})


def formulariom(request):
    producto_form = ProductoForm()

    if request.method == 'POST':
        producto_form = ProductoForm(request.POST, request.FILES)
        if producto_form.is_valid():
            producto = producto_form.save(commit=False)
            producto.mecanico = request.user.username
            producto = producto_form.save()
            return redirect('principal')  # Redirecciona a una página de éxito después de enviar el formulario

    context = {
        'producto_form': producto_form
    }
    return render(request, 'formulariom.html', context)


def solicitudes(request):
    solicitudes = Formulario.objects.filter(nombre=request.user)
    return render(request, 'solitudes.html', {'solicitudes': solicitudes})

def solicitudesm(request):
    solicitudes = Producto.objects.filter(mecanico=request.user)
    return render(request, 'solicitudesm.html', {'solicitudes': solicitudes})

def detalle_producto_view(request, producto_nombre):
    producto = get_object_or_404(Producto, nombre=producto_nombre)
    context = {
        'producto': producto
    }
    return render(request, 'detalle_producto.html', context)


def buscar(request):
    if request.method == 'GET':
        query = request.GET.get('q', '')  # Obtener los términos de búsqueda ingresados por el usuario
        categoria = request.GET.get('categoria', '')  # Obtener el tipo ingresado por el usuario
        mecanico = request.GET.get('mecanico', '')
        # Filtrar los formularios que contengan el término de búsqueda en el nombre y el tipo
        formularios = Producto.objects.filter(nombre__icontains=query, categoria__icontains=categoria,mecanico__icontains=mecanico)

        return render(request, 'buscar.html', {'formularios': formularios, 'query': query, 'categoria': categoria, 'mecanico': mecanico})

